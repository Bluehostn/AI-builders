import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { GradientButton } from "@/components/ui/gradient-button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Header } from "@/components/layout/Header"
import { 
  Plus, 
  Search, 
  Filter, 
  Grid, 
  List,
  Eye,
  Edit,
  Trash2,
  Download,
  Calendar,
  Globe
} from "lucide-react"

export default function Projects() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [searchTerm, setSearchTerm] = useState("")

  const projects = [
    {
      id: 1,
      name: "مطعم النخيل",
      description: "موقع مطعم بتصميم حديث ونظام حجز",
      status: "مكتمل",
      date: "2024-01-15",
      type: "مطعم",
      preview: "/placeholder.svg"
    },
    {
      id: 2,
      name: "شركة التقنية",
      description: "موقع شركة تقنية احترافي",
      status: "قيد التطوير",
      date: "2024-01-14",
      type: "شركة",
      preview: "/placeholder.svg"
    },
    {
      id: 3,
      name: "متجر الأزياء",
      description: "متجر إلكتروني للملابس والأزياء",
      status: "مكتمل",
      date: "2024-01-13",
      type: "متجر",
      preview: "/placeholder.svg"
    },
    {
      id: 4,
      name: "عيادة طبية",
      description: "موقع عيادة طبية مع نظام مواعيد",
      status: "مكتمل",
      date: "2024-01-12",
      type: "طبي",
      preview: "/placeholder.svg"
    }
  ]

  const filteredProjects = projects.filter(project =>
    project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    project.description.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="pt-20 pb-16">
        <div className="container mx-auto px-4">
          
          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-4">
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                مشاريعي
              </span>
            </h1>
            <p className="text-xl text-muted-foreground">
              إدارة وتصفح جميع مشاريعك المنشأة بالذكاء الاصطناعي
            </p>
          </div>

          {/* Controls */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="flex-1 relative">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input 
                placeholder="ابحث في المشاريع..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
            </div>
            
            <div className="flex gap-2">
              <Button variant="outline" size="icon">
                <Filter className="w-4 h-4" />
              </Button>
              
              <div className="flex border border-border rounded-md">
                <Button 
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className="rounded-l-md rounded-r-none"
                >
                  <Grid className="w-4 h-4" />
                </Button>
                <Button 
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className="rounded-r-md rounded-l-none"
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
              
              <GradientButton variant="hero">
                <Plus className="w-4 h-4 ml-2" />
                مشروع جديد
              </GradientButton>
            </div>
          </div>

          {/* Projects Grid/List */}
          {viewMode === 'grid' ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProjects.map((project) => (
                <Card key={project.id} className="overflow-hidden gradient-card border-purple-400/20 hover:shadow-glow transition-all duration-300">
                  <div className="aspect-video bg-secondary/10 relative overflow-hidden">
                    <img 
                      src={project.preview} 
                      alt={project.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                    <div className="absolute top-3 right-3">
                      <Badge 
                        variant="secondary" 
                        className={project.status === 'مكتمل' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}
                      >
                        {project.status}
                      </Badge>
                    </div>
                    <div className="absolute bottom-3 left-3 right-3 flex gap-2">
                      <Button size="sm" variant="secondary" className="bg-white/10 hover:bg-white/20 text-white">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="secondary" className="bg-white/10 hover:bg-white/20 text-white">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="secondary" className="bg-white/10 hover:bg-white/20 text-white">
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-lg">{project.name}</h3>
                      <Badge variant="outline">{project.type}</Badge>
                    </div>
                    <p className="text-muted-foreground text-sm mb-3">{project.description}</p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <div className="flex items-center">
                        <Calendar className="w-3 h-3 ml-1" />
                        {project.date}
                      </div>
                      <Button size="sm" variant="ghost">
                        <Globe className="w-3 h-3 ml-1" />
                        عرض
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredProjects.map((project) => (
                <Card key={project.id} className="p-4 gradient-card border-purple-400/20">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-secondary/10 rounded-lg overflow-hidden">
                      <img src={project.preview} alt={project.name} className="w-full h-full object-cover" />
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold">{project.name}</h3>
                        <Badge variant="outline" className="text-xs">{project.type}</Badge>
                        <Badge 
                          variant="secondary" 
                          className={project.status === 'مكتمل' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}
                        >
                          {project.status}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground text-sm">{project.description}</p>
                      <div className="flex items-center mt-2 text-xs text-muted-foreground">
                        <Calendar className="w-3 h-3 ml-1" />
                        {project.date}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline" className="text-red-500 hover:text-red-600">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}

          {filteredProjects.length === 0 && (
            <div className="text-center py-16">
              <div className="w-16 h-16 gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">لا توجد مشاريع</h3>
              <p className="text-muted-foreground mb-4">
                لم يتم العثور على مشاريع تطابق البحث
              </p>
              <GradientButton variant="hero">
                <Plus className="w-4 h-4 ml-2" />
                إنشاء مشروع جديد
              </GradientButton>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}