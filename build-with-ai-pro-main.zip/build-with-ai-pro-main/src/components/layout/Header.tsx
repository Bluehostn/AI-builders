import { GradientButton } from "@/components/ui/gradient-button"
import { Button } from "@/components/ui/button"
import { Code, Menu, Sparkles } from "lucide-react"

export function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center animate-glow">
            <Code className="w-4 h-4 text-white" />
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            AI WebBuilder
          </span>
        </div>

        <nav className="hidden md:flex items-center space-x-6">
          <Button variant="ghost" onClick={() => window.location.href = '/'}>الرئيسية</Button>
          <Button variant="ghost" onClick={() => window.location.href = '/projects'}>المشاريع</Button>
          <Button variant="ghost" onClick={() => window.location.href = '/templates'}>القوالب</Button>
          <Button variant="ghost" onClick={() => window.location.href = '/demo'}>العرض التوضيحي</Button>
        </nav>

        <div className="flex items-center space-x-4">
          <GradientButton variant="hero" size="default" onClick={() => window.location.href = '/projects'}>
            <Sparkles className="w-4 h-4 ml-2" />
            ابدأ الآن
          </GradientButton>
          <Button variant="outline" size="icon" className="md:hidden">
            <Menu className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </header>
  )
}