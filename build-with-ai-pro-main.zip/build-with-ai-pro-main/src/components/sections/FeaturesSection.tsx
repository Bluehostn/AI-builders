import { Card } from "@/components/ui/card"
import { 
  Wand2, 
  Palette, 
  Code2, 
  Smartphone, 
  Zap, 
  Globe,
  Download,
  Edit3,
  Eye,
  Settings
} from "lucide-react"

const features = [
  {
    icon: Wand2,
    title: "ذكاء اصطناعي متطور",
    description: "تقنيات GPT المتقدمة لفهم متطلباتك وإنشاء مواقع احترافية",
    color: "from-purple-400 to-pink-400"
  },
  {
    icon: Eye,
    title: "معاينة فورية",
    description: "شاهد موقعك يتكون أمامك مع إمكانية التعديل المباشر",
    color: "from-blue-400 to-cyan-400"
  },
  {
    icon: Palette,
    title: "تخصيص كامل",
    description: "تحكم في كل التفاصيل من الألوان والخطوط إلى التخطيط",
    color: "from-green-400 to-emerald-400"
  },
  {
    icon: Smartphone,
    title: "تصميم متجاوب",
    description: "مواقع تعمل بشكل مثالي على جميع الأجهزة والشاشات",
    color: "from-orange-400 to-red-400"
  },
  {
    icon: Code2,
    title: "كود نظيف",
    description: "أكواد عالية الجودة باستخدام أحدث التقنيات والمعايير",
    color: "from-indigo-400 to-purple-400"
  },
  {
    icon: Download,
    title: "تصدير متعدد",
    description: "صدّر مشروعك بصيغ مختلفة: HTML, React, Vue, وأكثر",
    color: "from-teal-400 to-blue-400"
  }
]

export function FeaturesSection() {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              مميزات قوية لإبداع لا محدود
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            تقنيات متطورة تجعل من إنشاء المواقع الإلكترونية تجربة سهلة وممتعة
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {features.map((feature, index) => (
            <Card 
              key={index}
              className="p-6 gradient-card border-purple-400/20 hover:scale-105 transition-bounce group animate-slide-up"
              style={{animationDelay: `${index * 0.1}s`}}
            >
              <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4 shadow-glow group-hover:animate-glow`}>
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2 group-hover:text-purple-400 transition-smooth">
                {feature.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </Card>
          ))}
        </div>

        {/* قسم إحصائيات إضافية */}
        <div className="mt-20 grid md:grid-cols-4 gap-8 text-center">
          <div className="animate-slide-up">
            <div className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-2">
              500+
            </div>
            <div className="text-muted-foreground">مكونات جاهزة</div>
          </div>
          <div className="animate-slide-up" style={{animationDelay: '0.1s'}}>
            <div className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent mb-2">
              24/7
            </div>
            <div className="text-muted-foreground">دعم فني</div>
          </div>
          <div className="animate-slide-up" style={{animationDelay: '0.2s'}}>
            <div className="text-4xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent mb-2">
              1s
            </div>
            <div className="text-muted-foreground">سرعة التوليد</div>
          </div>
          <div className="animate-slide-up" style={{animationDelay: '0.3s'}}>
            <div className="text-4xl font-bold bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text text-transparent mb-2">
              100%
            </div>
            <div className="text-muted-foreground">أمان البيانات</div>
          </div>
        </div>
      </div>
    </section>
  )
}