import { Button } from "@/components/ui/button"
import { GradientButton } from "@/components/ui/gradient-button"
import { Code, Github, Twitter, Linkedin, Mail } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-secondary/10 border-t border-border">
      <div className="container mx-auto px-4 py-16">
        
        {/* القسم الرئيسي */}
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          
          {/* الشعار والوصف */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center animate-glow">
                <Code className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                AI WebBuilder
              </span>
            </div>
            <p className="text-muted-foreground mb-6 max-w-md leading-relaxed">
              الحل الأمثل لإنشاء مواقع إلكترونية احترافية بتقنيات الذكاء الاصطناعي المتطورة. 
              ابدأ رحلتك الرقمية معنا اليوم.
            </p>
            <GradientButton variant="hero">
              ابدأ مجاناً الآن
            </GradientButton>
          </div>

          {/* الروابط السريعة */}
          <div>
            <h3 className="font-semibold mb-4">الروابط السريعة</h3>
            <div className="space-y-2">
              <Button variant="ghost" className="justify-start p-0 h-auto text-muted-foreground hover:text-foreground">
                الرئيسية
              </Button>
              <Button variant="ghost" className="justify-start p-0 h-auto text-muted-foreground hover:text-foreground">
                المشاريع
              </Button>
              <Button variant="ghost" className="justify-start p-0 h-auto text-muted-foreground hover:text-foreground">
                القوالب
              </Button>
              <Button variant="ghost" className="justify-start p-0 h-auto text-muted-foreground hover:text-foreground">
                الأسعار
              </Button>
            </div>
          </div>

          {/* الدعم */}
          <div>
            <h3 className="font-semibold mb-4">الدعم والمساعدة</h3>
            <div className="space-y-2">
              <Button variant="ghost" className="justify-start p-0 h-auto text-muted-foreground hover:text-foreground">
                التوثيق
              </Button>
              <Button variant="ghost" className="justify-start p-0 h-auto text-muted-foreground hover:text-foreground">
                الأسئلة الشائعة
              </Button>
              <Button variant="ghost" className="justify-start p-0 h-auto text-muted-foreground hover:text-foreground">
                تواصل معنا
              </Button>
              <Button variant="ghost" className="justify-start p-0 h-auto text-muted-foreground hover:text-foreground">
                المجتمع
              </Button>
            </div>
          </div>
        </div>

        {/* خط فاصل */}
        <div className="border-t border-border pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            
            {/* حقوق النشر */}
            <p className="text-muted-foreground text-sm">
              © 2024 AI WebBuilder. جميع الحقوق محفوظة.
            </p>

            {/* وسائل التواصل الاجتماعي */}
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="hover:text-purple-400">
                <Github className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-purple-400">
                <Twitter className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-purple-400">
                <Linkedin className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-purple-400">
                <Mail className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}