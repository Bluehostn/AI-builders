import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { GradientButton } from "@/components/ui/gradient-button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { 
  Play, 
  Download, 
  Save, 
  Eye, 
  Code, 
  Palette, 
  Layout,
  Smartphone,
  Monitor,
  Tablet
} from "lucide-react"

export function ProjectEditor() {
  const [prompt, setPrompt] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [currentView, setCurrentView] = useState<'desktop' | 'tablet' | 'mobile'>('desktop')

  const handleGenerate = async () => {
    setIsGenerating(true)
    // محاكاة عملية التوليد
    setTimeout(() => {
      setIsGenerating(false)
    }, 3000)
  }

  return (
    <section className="py-20 bg-secondary/10">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              محرر المشاريع الذكي
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            اكتب وصفاً لموقعك وشاهده يتكون أمامك بتقنيات الذكاء الاصطناعي المتقدمة
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 max-w-7xl mx-auto">
          
          {/* لوحة التحكم */}
          <Card className="p-6 gradient-card border-purple-400/20">
            <div className="space-y-6">
              
              {/* منطقة الإدخال */}
              <div>
                <label className="block text-sm font-medium mb-2">اكتب فكرة موقعك</label>
                <Textarea 
                  placeholder="مثال: أريد موقع لمطعم يقدم الطعام الإيطالي مع نظام حجز وقائمة طعام تفاعلية، التصميم يجب أن يكون أنيقاً وحديثاً مع ألوان دافئة..."
                  className="min-h-[120px] resize-none border-purple-400/30 focus:border-purple-400"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                />
              </div>

              {/* أدوات التصميم */}
              <div className="grid grid-cols-2 gap-4">
                <Button variant="outline" className="justify-start">
                  <Palette className="w-4 h-4 ml-2" />
                  اختر الألوان
                </Button>
                <Button variant="outline" className="justify-start">
                  <Layout className="w-4 h-4 ml-2" />
                  نوع التخطيط
                </Button>
              </div>

              {/* أزرار العمل */}
              <div className="flex gap-3">
                <GradientButton 
                  variant="hero" 
                  onClick={handleGenerate}
                  disabled={!prompt.trim() || isGenerating}
                  className="flex-1"
                >
                  <Play className="w-4 h-4 ml-2" />
                  {isGenerating ? "جاري التوليد..." : "أنشئ الموقع"}
                </GradientButton>
                <Button variant="outline" size="icon">
                  <Save className="w-4 h-4" />
                </Button>
              </div>

              {/* خيارات التصدير */}
              <div className="pt-4 border-t border-border">
                <h3 className="font-semibold mb-3">تصدير المشروع</h3>
                <div className="grid grid-cols-2 gap-3">
                  <Button variant="outline" size="sm">
                    <Code className="w-4 h-4 ml-2" />
                    HTML/CSS
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 ml-2" />
                    React
                  </Button>
                </div>
              </div>

            </div>
          </Card>

          {/* منطقة المعاينة */}
          <Card className="p-6 gradient-card border-purple-400/20">
            <div className="space-y-4">
              
              {/* أدوات المعاينة */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="bg-purple-400/20 text-purple-400">
                    معاينة مباشرة
                  </Badge>
                  <Eye className="w-4 h-4 text-muted-foreground" />
                </div>
                
                <div className="flex gap-1">
                  <Button 
                    variant={currentView === 'desktop' ? 'default' : 'outline'} 
                    size="sm"
                    onClick={() => setCurrentView('desktop')}
                  >
                    <Monitor className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant={currentView === 'tablet' ? 'default' : 'outline'} 
                    size="sm"
                    onClick={() => setCurrentView('tablet')}
                  >
                    <Tablet className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant={currentView === 'mobile' ? 'default' : 'outline'} 
                    size="sm"
                    onClick={() => setCurrentView('mobile')}
                  >
                    <Smartphone className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* شاشة المعاينة */}
              <div className="aspect-video bg-background border-2 border-purple-400/30 rounded-lg overflow-hidden relative">
                {isGenerating ? (
                  <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-purple-400/10 to-pink-400/10">
                    <div className="text-center space-y-4">
                      <div className="w-12 h-12 gradient-primary rounded-full animate-spin border-4 border-white/30 border-t-white mx-auto"></div>
                      <p className="text-lg font-medium">جاري إنشاء موقعك الإلكتروني...</p>
                      <p className="text-sm text-muted-foreground">قد يستغرق الأمر بضع ثوان</p>
                    </div>
                  </div>
                ) : (
                  <div className="p-8 h-full flex items-center justify-center text-center">
                    <div className="space-y-4">
                      <div className="w-16 h-16 gradient-primary rounded-full flex items-center justify-center mx-auto animate-float">
                        <Code className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-xl font-semibold">اكتب فكرتك لنبدأ</h3>
                      <p className="text-muted-foreground">
                        ستظهر معاينة موقعك هنا بمجرد الضغط على "أنشئ الموقع"
                      </p>
                    </div>
                  </div>
                )}
              </div>
              
            </div>
          </Card>
          
        </div>
      </div>
    </section>
  )
}