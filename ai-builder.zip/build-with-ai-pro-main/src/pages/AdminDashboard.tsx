import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { GradientButton } from "@/components/ui/gradient-button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Settings, 
  Users, 
  Globe, 
  Palette, 
  Code,
  MessageSquare,
  Save,
  Eye,
  Sparkles,
  Bot,
  Send
} from "lucide-react"

export default function AdminDashboard() {
  const [aiPrompt, setAiPrompt] = useState("")
  const [isAiWorking, setIsAiWorking] = useState(false)

  const handleAiAssist = async () => {
    if (!aiPrompt.trim()) return
    setIsAiWorking(true)
    // محاكاة المساعد الذكي
    setTimeout(() => {
      setIsAiWorking(false)
      setAiPrompt("")
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center">
              <Settings className="w-4 h-4 text-white" />
            </div>
            <span className="text-xl font-bold">لوحة تحكم الأدمن</span>
          </div>
          <GradientButton variant="hero" size="sm">
            <Eye className="w-4 h-4 ml-2" />
            معاينة الموقع
          </GradientButton>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="p-6 gradient-card">
              <h3 className="font-semibold mb-4 flex items-center">
                <Bot className="w-5 h-5 ml-2" />
                المساعد الذكي
              </h3>
              <div className="space-y-4">
                <Textarea
                  placeholder="اكتب طلبك للمساعد الذكي... مثل: غير لون الهيدر إلى الأزرق، أضف قسم جديد، حدث النص..."
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  className="min-h-[100px] resize-none"
                />
                <GradientButton 
                  variant="hero" 
                  onClick={handleAiAssist}
                  disabled={!aiPrompt.trim() || isAiWorking}
                  className="w-full"
                >
                  <Send className="w-4 h-4 ml-2" />
                  {isAiWorking ? "جاري التنفيذ..." : "تنفيذ"}
                </GradientButton>
              </div>

              {/* Quick Actions */}
              <div className="mt-6 pt-6 border-t border-border">
                <h4 className="font-medium mb-3">إجراءات سريعة</h4>
                <div className="space-y-2">
                  <Button variant="outline" size="sm" className="w-full justify-start">
                    <Palette className="w-4 h-4 ml-2" />
                    تغيير الألوان
                  </Button>
                  <Button variant="outline" size="sm" className="w-full justify-start">
                    <Code className="w-4 h-4 ml-2" />
                    تحرير الكود
                  </Button>
                  <Button variant="outline" size="sm" className="w-full justify-start">
                    <Globe className="w-4 h-4 ml-2" />
                    إعدادات SEO
                  </Button>
                </div>
              </div>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="general" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="general">عام</TabsTrigger>
                <TabsTrigger value="design">التصميم</TabsTrigger>
                <TabsTrigger value="content">المحتوى</TabsTrigger>
                <TabsTrigger value="users">المستخدمين</TabsTrigger>
              </TabsList>

              <TabsContent value="general" className="space-y-6">
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">الإعدادات العامة</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">اسم الموقع</label>
                      <Input defaultValue="AI WebBuilder" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">الوصف</label>
                      <Input defaultValue="منصة إنشاء المواقع بالذكاء الاصطناعي" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">البريد الإلكتروني</label>
                      <Input defaultValue="admin@aiwebbuilder.com" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">رقم الهاتف</label>
                      <Input defaultValue="+966501234567" />
                    </div>
                  </div>
                </Card>

                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">إحصائيات الموقع</h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-secondary/10 rounded-lg">
                      <div className="text-2xl font-bold text-primary">1,234</div>
                      <div className="text-sm text-muted-foreground">مشروع منشأ</div>
                    </div>
                    <div className="text-center p-4 bg-secondary/10 rounded-lg">
                      <div className="text-2xl font-bold text-primary">567</div>
                      <div className="text-sm text-muted-foreground">مستخدم نشط</div>
                    </div>
                    <div className="text-center p-4 bg-secondary/10 rounded-lg">
                      <div className="text-2xl font-bold text-primary">89</div>
                      <div className="text-sm text-muted-foreground">قالب متاح</div>
                    </div>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="design" className="space-y-6">
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">إعدادات التصميم</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">اللون الأساسي</label>
                      <div className="flex gap-2">
                        <div className="w-8 h-8 rounded bg-purple-500 cursor-pointer border-2 border-white shadow-sm"></div>
                        <div className="w-8 h-8 rounded bg-blue-500 cursor-pointer border-2 border-transparent"></div>
                        <div className="w-8 h-8 rounded bg-green-500 cursor-pointer border-2 border-transparent"></div>
                        <div className="w-8 h-8 rounded bg-orange-500 cursor-pointer border-2 border-transparent"></div>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">الخط الأساسي</label>
                      <select className="w-full p-2 border border-border rounded-md">
                        <option>Inter</option>
                        <option>Roboto</option>
                        <option>Open Sans</option>
                        <option>Tajawal</option>
                      </select>
                    </div>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="content" className="space-y-6">
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">إدارة المحتوى</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">نص الهيرو الرئيسي</label>
                      <Input defaultValue="اصنع موقعك الالكتروني بالذكاء الاصطناعي" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">الوصف التفصيلي</label>
                      <Textarea 
                        defaultValue="منصة متطورة لإنشاء المواقع الإلكترونية باستخدام تقنيات الذكاء الاصطناعي المتقدمة"
                        className="min-h-[100px]"
                      />
                    </div>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="users" className="space-y-6">
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">إدارة المستخدمين</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">المستخدمون المسجلون</h4>
                      <Badge variant="secondary">567 مستخدم</Badge>
                    </div>
                    <div className="border border-border rounded-lg overflow-hidden">
                      <table className="w-full">
                        <thead className="bg-secondary/10">
                          <tr>
                            <th className="p-3 text-right">الاسم</th>
                            <th className="p-3 text-right">البريد</th>
                            <th className="p-3 text-right">تاريخ التسجيل</th>
                            <th className="p-3 text-right">الحالة</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-t border-border">
                            <td className="p-3">أحمد محمد</td>
                            <td className="p-3">ahmed@example.com</td>
                            <td className="p-3">2024-01-15</td>
                            <td className="p-3">
                              <Badge variant="secondary" className="bg-green-100 text-green-800">نشط</Badge>
                            </td>
                          </tr>
                          <tr className="border-t border-border">
                            <td className="p-3">فاطمة علي</td>
                            <td className="p-3">fatima@example.com</td>
                            <td className="p-3">2024-01-14</td>
                            <td className="p-3">
                              <Badge variant="secondary" className="bg-green-100 text-green-800">نشط</Badge>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Save Button */}
            <div className="mt-8 flex justify-end">
              <GradientButton variant="hero" size="lg">
                <Save className="w-5 h-5 ml-2" />
                حفظ التغييرات
              </GradientButton>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}