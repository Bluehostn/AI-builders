import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { GradientButton } from "@/components/ui/gradient-button"
import { Badge } from "@/components/ui/badge"
import { Header } from "@/components/layout/Header"
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Maximize2,
  Monitor,
  Tablet,
  Smartphone,
  Code,
  Download,
  Share2,
  Clock,
  Globe
} from "lucide-react"

export default function Demo() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)
  const [viewMode, setViewMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop')
  const [progress, setProgress] = useState(0)

  const demoSteps = [
    {
      title: "إدخال الفكرة",
      description: "يكتب المستخدم وصف موقعه المطلوب",
      duration: 3000
    },
    {
      title: "تحليل المتطلبات", 
      description: "الذكاء الاصطناعي يحلل الطلب ويحدد العناصر",
      duration: 2000
    },
    {
      title: "إنشاء التصميم",
      description: "توليد التصميم والألوان والتخطيط",
      duration: 4000
    },
    {
      title: "كتابة الكود",
      description: "إنشاء كود HTML/CSS/JavaScript",
      duration: 3000
    },
    {
      title: "المعاينة النهائية",
      description: "عرض الموقع كاملاً وجاهزاً للاستخدام",
      duration: 2000
    }
  ]

  useEffect(() => {
    let interval: NodeJS.Timeout
    
    if (isPlaying) {
      interval = setInterval(() => {
        setProgress(prev => {
          const newProgress = prev + (100 / (demoSteps[currentStep].duration / 100))
          
          if (newProgress >= 100) {
            if (currentStep < demoSteps.length - 1) {
              setCurrentStep(currentStep + 1)
              return 0
            } else {
              setIsPlaying(false)
              return 100
            }
          }
          
          return newProgress
        })
      }, 100)
    }
    
    return () => clearInterval(interval)
  }, [isPlaying, currentStep])

  const handlePlay = () => {
    setIsPlaying(!isPlaying)
  }

  const handleRestart = () => {
    setIsPlaying(false)
    setCurrentStep(0)
    setProgress(0)
  }

  const getViewModeClass = () => {
    switch (viewMode) {
      case 'mobile': return 'max-w-sm mx-auto'
      case 'tablet': return 'max-w-2xl mx-auto'
      default: return 'w-full'
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="pt-20 pb-16">
        <div className="container mx-auto px-4">
          
          {/* Page Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                العرض التوضيحي
              </span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              شاهد كيف يعمل الذكاء الاصطناعي على إنشاء موقعك من الفكرة إلى النتيجة النهائية
            </p>
          </div>

          <div className="grid lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
            
            {/* Controls Panel */}
            <div className="lg:col-span-1">
              <Card className="p-6 gradient-card border-purple-400/20 sticky top-8">
                <h3 className="font-semibold mb-4">التحكم في العرض</h3>
                
                {/* Play Controls */}
                <div className="space-y-4 mb-6">
                  <GradientButton 
                    variant="hero" 
                    onClick={handlePlay}
                    className="w-full"
                  >
                    {isPlaying ? (
                      <>
                        <Pause className="w-4 h-4 ml-2" />
                        إيقاف
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 ml-2" />
                        تشغيل
                      </>
                    )}
                  </GradientButton>
                  
                  <Button variant="outline" onClick={handleRestart} className="w-full">
                    <RotateCcw className="w-4 h-4 ml-2" />
                    إعادة تشغيل
                  </Button>
                </div>

                {/* View Mode */}
                <div className="space-y-3 mb-6">
                  <h4 className="font-medium">وضع العرض</h4>
                  <div className="grid grid-cols-3 gap-1">
                    <Button 
                      variant={viewMode === 'desktop' ? 'default' : 'outline'} 
                      size="sm"
                      onClick={() => setViewMode('desktop')}
                    >
                      <Monitor className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant={viewMode === 'tablet' ? 'default' : 'outline'} 
                      size="sm"
                      onClick={() => setViewMode('tablet')}
                    >
                      <Tablet className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant={viewMode === 'mobile' ? 'default' : 'outline'} 
                      size="sm"
                      onClick={() => setViewMode('mobile')}
                    >
                      <Smartphone className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Steps Progress */}
                <div className="space-y-3">
                  <h4 className="font-medium">مراحل الإنشاء</h4>
                  {demoSteps.map((step, index) => (
                    <div 
                      key={index} 
                      className={`p-3 rounded-lg border transition-all ${
                        index === currentStep 
                          ? 'border-purple-400 bg-purple-400/10' 
                          : index < currentStep 
                            ? 'border-green-400 bg-green-400/10'
                            : 'border-border bg-secondary/10'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">{step.title}</span>
                        {index === currentStep && (
                          <Badge variant="secondary" className="bg-purple-400/20 text-purple-400">
                            جاري التنفيذ
                          </Badge>
                        )}
                        {index < currentStep && (
                          <Badge variant="secondary" className="bg-green-400/20 text-green-400">
                            مكتمل
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">{step.description}</p>
                      {index === currentStep && (
                        <div className="mt-2 w-full bg-border rounded-full h-1">
                          <div 
                            className="h-1 gradient-primary rounded-full transition-all duration-100"
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Actions */}
                <div className="mt-6 pt-6 border-t border-border space-y-2">
                  <Button variant="outline" size="sm" className="w-full">
                    <Code className="w-4 h-4 ml-2" />
                    عرض الكود
                  </Button>
                  <Button variant="outline" size="sm" className="w-full">
                    <Download className="w-4 h-4 ml-2" />
                    تحميل المشروع
                  </Button>
                  <Button variant="outline" size="sm" className="w-full">
                    <Share2 className="w-4 h-4 ml-2" />
                    مشاركة
                  </Button>
                </div>
              </Card>
            </div>

            {/* Demo Preview */}
            <div className="lg:col-span-3">
              <Card className="p-6 gradient-card border-purple-400/20">
                <div className="space-y-4">
                  
                  {/* Header */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="bg-purple-400/20 text-purple-400">
                        عرض توضيحي مباشر
                      </Badge>
                      {isPlaying && (
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Clock className="w-4 h-4 ml-1" />
                          {demoSteps[currentStep]?.title}
                        </div>
                      )}
                    </div>
                    
                    <Button variant="outline" size="sm">
                      <Maximize2 className="w-4 h-4" />
                    </Button>
                  </div>

                  {/* Preview Screen */}
                  <div className={`${getViewModeClass()} transition-all duration-300`}>
                    <div className="aspect-video bg-background border-2 border-purple-400/30 rounded-lg overflow-hidden relative">
                      
                      {!isPlaying && currentStep === 0 ? (
                        // Initial State
                        <div className="h-full flex items-center justify-center text-center p-8">
                          <div className="space-y-4">
                            <div className="w-16 h-16 gradient-primary rounded-full flex items-center justify-center mx-auto">
                              <Play className="w-8 h-8 text-white" />
                            </div>
                            <h3 className="text-xl font-semibold">ابدأ العرض التوضيحي</h3>
                            <p className="text-muted-foreground">
                              اضغط على تشغيل لمشاهدة كيفية إنشاء موقع كامل بالذكاء الاصطناعي
                            </p>
                          </div>
                        </div>
                      ) : (
                        // Demo Content Based on Current Step
                        <div className="h-full p-4 overflow-hidden">
                          {currentStep === 0 && (
                            <div className="space-y-4">
                              <div className="bg-card p-4 rounded-lg border">
                                <h4 className="font-medium mb-2">إدخال فكرة الموقع</h4>
                                <div className="text-sm text-muted-foreground">
                                  "أريد موقع لمطعم يقدم الطعام الإيطالي مع نظام حجز..."
                                </div>
                              </div>
                            </div>
                          )}
                          
                          {currentStep === 1 && (
                            <div className="space-y-4">
                              <div className="bg-card p-4 rounded-lg border">
                                <h4 className="font-medium mb-2">تحليل المتطلبات</h4>
                                <div className="space-y-2 text-sm">
                                  <div className="flex items-center justify-between">
                                    <span>نوع الموقع: مطعم</span>
                                    <Badge variant="outline">تم التحديد</Badge>
                                  </div>
                                  <div className="flex items-center justify-between">
                                    <span>الميزات المطلوبة: حجز، قائمة طعام</span>
                                    <Badge variant="outline">تم التحديد</Badge>
                                  </div>
                                  <div className="flex items-center justify-between">
                                    <span>الألوان: دافئة</span>
                                    <Badge variant="outline">تم التحديد</Badge>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                          
                          {currentStep === 2 && (
                            <div className="space-y-4">
                              <div className="bg-card p-4 rounded-lg border">
                                <h4 className="font-medium mb-2">إنشاء التصميم</h4>
                                <div className="grid grid-cols-2 gap-2">
                                  <div className="h-20 bg-gradient-to-r from-orange-400 to-red-400 rounded animate-pulse"></div>
                                  <div className="h-20 bg-gradient-to-r from-yellow-400 to-orange-400 rounded animate-pulse delay-100"></div>
                                  <div className="h-8 bg-secondary rounded animate-pulse delay-200"></div>
                                  <div className="h-8 bg-secondary rounded animate-pulse delay-300"></div>
                                </div>
                              </div>
                            </div>
                          )}
                          
                          {currentStep === 3 && (
                            <div className="space-y-4">
                              <div className="bg-card p-4 rounded-lg border">
                                <h4 className="font-medium mb-2">كتابة الكود</h4>
                                <div className="space-y-1 text-xs font-mono">
                                  <div className="text-blue-500">&lt;header className="bg-orange-500"&gt;</div>
                                  <div className="ml-4 text-green-500">&lt;nav&gt;القائمة | حجز طاولة&lt;/nav&gt;</div>
                                  <div className="text-blue-500">&lt;/header&gt;</div>
                                  <div className="text-blue-500">&lt;main&gt;</div>
                                  <div className="ml-4 text-purple-500">// محتوى الموقع...</div>
                                </div>
                              </div>
                            </div>
                          )}
                          
                          {currentStep === 4 && (
                            <div className="h-full bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950 dark:to-red-950">
                              <div className="h-16 bg-gradient-to-r from-orange-500 to-red-500 flex items-center justify-between px-4">
                                <div className="text-white font-bold">مطعم النخيل</div>
                                <div className="flex gap-2 text-white text-sm">
                                  <span>القائمة</span>
                                  <span>حجز طاولة</span>
                                  <span>تواصل معنا</span>
                                </div>
                              </div>
                              <div className="p-4 space-y-4">
                                <div className="text-center py-8">
                                  <h2 className="text-2xl font-bold mb-2">أفضل الأطباق الإيطالية</h2>
                                  <p className="text-muted-foreground">تجربة طعام لا تُنسى في قلب المدينة</p>
                                </div>
                                <div className="grid grid-cols-3 gap-2">
                                  <div className="h-16 bg-orange-200 dark:bg-orange-800 rounded"></div>
                                  <div className="h-16 bg-red-200 dark:bg-red-800 rounded"></div>
                                  <div className="h-16 bg-yellow-200 dark:bg-yellow-800 rounded"></div>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </div>

          {/* Demo Features */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-center mb-8">ما يمكن إنشاؤه بالذكاء الاصطناعي</h2>
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="p-6 text-center gradient-card border-purple-400/20">
                <div className="w-12 h-12 gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Globe className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold mb-2">مواقع الأعمال</h3>
                <p className="text-sm text-muted-foreground">مواقع احترافية للشركات والخدمات</p>
              </Card>
              
              <Card className="p-6 text-center gradient-card border-purple-400/20">
                <div className="w-12 h-12 gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Code className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold mb-2">متاجر إلكترونية</h3>
                <p className="text-sm text-muted-foreground">منصات بيع مع أنظمة دفع متكاملة</p>
              </Card>
              
              <Card className="p-6 text-center gradient-card border-purple-400/20">
                <div className="w-12 h-12 gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Download className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold mb-2">مدونات شخصية</h3>
                <p className="text-sm text-muted-foreground">منصات محتوى وتدوين احترافية</p>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}