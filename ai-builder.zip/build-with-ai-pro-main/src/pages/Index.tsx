import { Header } from "@/components/layout/Header"
import { HeroSection } from "@/components/sections/HeroSection"
import { ProjectEditor } from "@/components/sections/ProjectEditor"
import { FeaturesSection } from "@/components/sections/FeaturesSection"
import { Footer } from "@/components/sections/Footer"

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <HeroSection />
      <ProjectEditor />
      <FeaturesSection />
      <Footer />
    </div>
  );
};

export default Index;
