import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { GradientButton } from "@/components/ui/gradient-button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Header } from "@/components/layout/Header"
import { 
  Search, 
  Filter, 
  Grid, 
  List,
  Eye,
  Download,
  Star,
  Users,
  Zap
} from "lucide-react"

export default function Templates() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")

  const categories = [
    { id: "all", name: "الكل", count: 89 },
    { id: "business", name: "أعمال", count: 25 },
    { id: "restaurant", name: "مطاعم", count: 18 },
    { id: "portfolio", name: "معرض أعمال", count: 15 },
    { id: "ecommerce", name: "متاجر", count: 12 },
    { id: "blog", name: "مدونات", count: 10 },
    { id: "healthcare", name: "طبي", count: 9 }
  ]

  const templates = [
    {
      id: 1,
      name: "مطعم فاخر",
      description: "قالب حديث للمطاعم الراقية مع نظام حجز",
      category: "restaurant",
      rating: 4.8,
      downloads: 1234,
      isPremium: false,
      preview: "/placeholder.svg",
      features: ["حجز المواعيد", "قائمة الطعام", "تصميم متجاوب"]
    },
    {
      id: 2,
      name: "شركة تقنية احترافية",
      description: "موقع احترافي لشركات التقنية والبرمجة",
      category: "business",
      rating: 4.9,
      downloads: 2156,
      isPremium: true,
      preview: "/placeholder.svg",
      features: ["صفحة الخدمات", "فريق العمل", "معرض المشاريع"]
    },
    {
      id: 3,
      name: "متجر الموضة",
      description: "متجر إلكتروني أنيق للأزياء والملابس",
      category: "ecommerce",
      rating: 4.7,
      downloads: 987,
      isPremium: false,
      preview: "/placeholder.svg",
      features: ["سلة التسوق", "صفحات المنتجات", "الدفع الآمن"]
    },
    {
      id: 4,
      name: "معرض أعمال فني",
      description: "قالب إبداعي لعرض الأعمال الفنية",
      category: "portfolio",
      rating: 4.6,
      downloads: 756,
      isPremium: true,
      preview: "/placeholder.svg",
      features: ["معرض الصور", "صفحة السيرة", "تواصل معي"]
    },
    {
      id: 5,
      name: "عيادة طبية",
      description: "موقع متكامل للعيادات الطبية",
      category: "healthcare",
      rating: 4.8,
      downloads: 643,
      isPremium: false,
      preview: "/placeholder.svg",
      features: ["حجز المواعيد", "الخدمات الطبية", "فريق الأطباء"]
    },
    {
      id: 6,
      name: "مدونة شخصية",
      description: "قالب أنيق للمدونات الشخصية",
      category: "blog",
      rating: 4.5,
      downloads: 432,
      isPremium: false,
      preview: "/placeholder.svg",
      features: ["المقالات", "التعليقات", "الأرشيف"]
    }
  ]

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || template.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="pt-20 pb-16">
        <div className="container mx-auto px-4">
          
          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-4">
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                قوالب المواقع
              </span>
            </h1>
            <p className="text-xl text-muted-foreground">
              اختر من مجموعة واسعة من القوالب المصممة بعناية لجميع الأغراض
            </p>
          </div>

          <div className="flex flex-col lg:flex-row gap-8">
            
            {/* Sidebar */}
            <div className="lg:w-64">
              <Card className="p-6 gradient-card border-purple-400/20">
                <h3 className="font-semibold mb-4">التصنيفات</h3>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <Button
                      key={category.id}
                      variant={selectedCategory === category.id ? "default" : "ghost"}
                      className="w-full justify-between"
                      onClick={() => setSelectedCategory(category.id)}
                    >
                      <span>{category.name}</span>
                      <Badge variant="secondary" className="bg-secondary/50">
                        {category.count}
                      </Badge>
                    </Button>
                  ))}
                </div>
              </Card>
            </div>

            {/* Main Content */}
            <div className="flex-1">
              
              {/* Controls */}
              <div className="flex flex-col md:flex-row gap-4 mb-8">
                <div className="flex-1 relative">
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input 
                    placeholder="ابحث في القوالب..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pr-10"
                  />
                </div>
                
                <div className="flex gap-2">
                  <Button variant="outline" size="icon">
                    <Filter className="w-4 h-4" />
                  </Button>
                  
                  <div className="flex border border-border rounded-md">
                    <Button 
                      variant={viewMode === 'grid' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setViewMode('grid')}
                      className="rounded-l-md rounded-r-none"
                    >
                      <Grid className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant={viewMode === 'list' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setViewMode('list')}
                      className="rounded-r-md rounded-l-none"
                    >
                      <List className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Templates Grid/List */}
              {viewMode === 'grid' ? (
                <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredTemplates.map((template) => (
                    <Card key={template.id} className="overflow-hidden gradient-card border-purple-400/20 hover:shadow-glow transition-all duration-300">
                      <div className="aspect-video bg-secondary/10 relative overflow-hidden">
                        <img 
                          src={template.preview} 
                          alt={template.name}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                        {template.isPremium && (
                          <div className="absolute top-3 right-3">
                            <Badge className="gradient-primary text-white">
                              <Zap className="w-3 h-3 ml-1" />
                              مميز
                            </Badge>
                          </div>
                        )}
                        <div className="absolute bottom-3 left-3 right-3 flex gap-2">
                          <Button size="sm" variant="secondary" className="bg-white/10 hover:bg-white/20 text-white flex-1">
                            <Eye className="w-4 h-4 ml-2" />
                            معاينة
                          </Button>
                          <GradientButton size="sm" variant="hero" className="flex-1">
                            <Download className="w-4 h-4 ml-2" />
                            استخدم
                          </GradientButton>
                        </div>
                      </div>
                      
                      <div className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-semibold text-lg">{template.name}</h3>
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Star className="w-3 h-3 ml-1 text-yellow-500 fill-current" />
                            {template.rating}
                          </div>
                        </div>
                        <p className="text-muted-foreground text-sm mb-3">{template.description}</p>
                        
                        <div className="flex flex-wrap gap-1 mb-3">
                          {template.features.slice(0, 2).map((feature, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                          {template.features.length > 2 && (
                            <Badge variant="outline" className="text-xs">
                              +{template.features.length - 2}
                            </Badge>
                          )}
                        </div>
                        
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <div className="flex items-center">
                            <Users className="w-3 h-3 ml-1" />
                            {template.downloads} استخدام
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredTemplates.map((template) => (
                    <Card key={template.id} className="p-4 gradient-card border-purple-400/20">
                      <div className="flex items-center gap-4">
                        <div className="w-20 h-20 bg-secondary/10 rounded-lg overflow-hidden">
                          <img src={template.preview} alt={template.name} className="w-full h-full object-cover" />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold">{template.name}</h3>
                            {template.isPremium && (
                              <Badge className="gradient-primary text-white text-xs">
                                <Zap className="w-3 h-3 ml-1" />
                                مميز
                              </Badge>
                            )}
                            <div className="flex items-center text-sm text-muted-foreground">
                              <Star className="w-3 h-3 ml-1 text-yellow-500 fill-current" />
                              {template.rating}
                            </div>
                          </div>
                          <p className="text-muted-foreground text-sm mb-2">{template.description}</p>
                          <div className="flex flex-wrap gap-1 mb-2">
                            {template.features.map((feature, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {feature}
                              </Badge>
                            ))}
                          </div>
                          <div className="flex items-center text-xs text-muted-foreground">
                            <Users className="w-3 h-3 ml-1" />
                            {template.downloads} استخدام
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Button size="sm" variant="outline">
                            <Eye className="w-4 h-4 ml-2" />
                            معاينة
                          </Button>
                          <GradientButton size="sm" variant="hero">
                            <Download className="w-4 h-4 ml-2" />
                            استخدم القالب
                          </GradientButton>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}

              {filteredTemplates.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-16 h-16 gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">لا توجد قوالب</h3>
                  <p className="text-muted-foreground">
                    لم يتم العثور على قوالب تطابق البحث في هذا التصنيف
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}